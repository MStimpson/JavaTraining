package com.eaglecrk.inventory;

public class MediaRecord {

	private int id;
	private String title;
	private String description;
	private int minutes;
	private int year;
	private String genre;

	MediaRecord(int id, String title, String description, int minutes, int year, String genre) {
		this.id = id;
		this.title = title;
		this.description = description;
		this.minutes = minutes;
		this.year = year;
		this.genre = genre;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the minutes
	 */
	public int getMinutes() {
		return minutes;
	}

	/**
	 * @param minutes the minutes to set
	 */
	public void setMinutes(int minutes) {
		this.minutes = minutes;
	}

	/**
	 * @return the year
	 */
	public int getYear() {
		return year;
	}

	/**
	 * @param year the year to set
	 */
	public void setYear(int year) {
		this.year = year;
	}

	/**
	 * @return the genre
	 */
	public String getGenre() {
		return genre == null ? "" : genre;
	}

	/**
	 * @param genre the genre to set
	 */
	public void setGenre(String genre) {
		this.genre = genre;
	}

	public Object[] getColumns() {
		Object[] columns = new Object[5];
		columns[0] = title;
		columns[1] = description;
		columns[2] = genre;
		columns[3] = minutes;
		columns[4] = year;
		return columns;
	}
	
	public String toString() {
		return "" + id + ": " + title + "; " + description + "; " + genre +"; " + minutes +"; " + year;
	}

}
