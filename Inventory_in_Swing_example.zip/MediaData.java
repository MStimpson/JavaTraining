package com.eaglecrk.inventory;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * Media Data Access.
 * 
 * @author Jesse, ECSS, Mar2017
 *
 */
public class MediaData {

	public final String[] columns = { "title", "description", "genre", "minutes", "year" };
	private Connection conn;
	
	public MediaData() {
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/inventory?useSSL=false", "media", "media");
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}
	
	public List<MediaRecord> getRecords() {
		return getRecords("SELECT * FROM media");
	}
	
	public List<MediaRecord> getRecords(String query) {
		List<MediaRecord> list = new ArrayList<>();
		try {
			Statement stmt = conn.createStatement();
	        ResultSet rs = stmt.executeQuery(query);
	        while (rs.next()) {
	        	int id = rs.getInt("id");
	        	String title = rs.getString("title");
	        	String description = rs.getString("description");
	        	int minutes = rs.getInt("minutes");
	        	int year = rs.getInt("year");
	        	String genre = rs.getString("genre");
	        	MediaRecord record = new MediaRecord(id, title, description, minutes, year, genre);
	        	list.add(record);
	        }
	        stmt.close();
	        return list;
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return null;
	}
	
	public boolean addRecord(MediaRecord record) {
		int i;
		try {
			PreparedStatement preparedStmt = conn.prepareStatement("INSERT INTO users VALUES(0,?,?,?,?,?,?,?,null)");
//			preparedStmt.setString (1, user.getUsername());
//			preparedStmt.setString (2, user.getPassword());
//			preparedStmt.setString (3, user.getLastname());
//			preparedStmt.setString (4, user.getFirstname());
//			preparedStmt.setString (5, user.getEmail());
//			preparedStmt.setString (6, user.getPhone());
//			preparedStmt.setBoolean (7, user.isAdmin());
			i = preparedStmt.executeUpdate();		
		} catch (SQLException ex) {
			ex.printStackTrace();
			i = 0;
		}
		return i > 0;
	}
	
	public boolean removeRecord(int id) {
		int i;
		try {
			PreparedStatement preparedStmt = conn.prepareStatement("DELETE FROM media WHERE id = ?");
			preparedStmt.setInt (1, id);
			i = preparedStmt.executeUpdate();		
		} catch (SQLException ex) {
			ex.printStackTrace();
			i = 0;
		}
		return i > 0;
	}
	
}
