package com.eaglecrk.inventory;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;

/**
 * Media Inventory (Swing GUI)
 * 
 * @author Jesse, ECSS, 3/29/2017
 *
 */
public class MediaMain {

	private JFrame frame;
	private MediaData db;
	private Counters counters;

	/**
	 * Instantiates the main class.
	 * 
	 */
	public MediaMain() {
		counters = new Counters();
		initialize();
		db = new MediaData();
	}

	/**
	 * Initializes the outer window frame.
	 * 
	 */
	private void initialize() {
		// Setup initial app window ..
		frame = new JFrame("Media Inventory System");
		frame.setBounds(100, 100, 650, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	/**
	 * Creates the various tabbed components.
	 * 
	 */
	private void setupComponents() {
		frame.setLayout(null);	// Set basic frame layout

		//// OVERVIEW TAB ////

		JPanel overviewPanel = new JPanel();
		overviewPanel.setLayout(null);	// Set basic panel layout
		
		// Overview Title ..
		JLabel overviewTitle = new JLabel();
		overviewTitle.setBounds(20, 10, 300, 30);// x, y, width, height - (pixels)
		overviewTitle.setText("Overview");
		overviewTitle.setFont(new Font("Arial", Font.BOLD, 24));
		overviewTitle.setForeground(Color.red);
		overviewTitle.setVisible(true);
		overviewPanel.add(overviewTitle);

		// Overview text ..
		JLabel overviewText = new JLabel();
		overviewText.setBounds(20, 50, 300, 300);
		
		showOverview(overviewText);
		overviewText.setVisible(true);
		overviewPanel.add(overviewText);

		//// SEARCH TAB ////

		JPanel searchPanel = new JPanel();
		searchPanel.setLayout(null);	// Set basic panel layout
		
		// Search Title ..
		JLabel searchTitle = new JLabel();
		searchTitle.setBounds(20, 10, 300, 30);// x, y, width, height - (pixels)
		searchTitle.setText("Search");
		searchTitle.setFont(new Font("Arial", Font.BOLD, 24));
		searchTitle.setForeground(Color.red);
		searchTitle.setVisible(true);
		searchPanel.add(searchTitle);

		// Search text field ..
		JTextField searchText = new JTextField();
		searchText.setBounds(20, 50, 450,  30);
		searchText.setVisible(true);
		searchPanel.add(searchText);

		// Search table
		Object[] headings = { "Title","Description","Genre","Minutes","Year" };
		int[] colWidth = { 150, 250, 100, 40, 40 };
		JScrollPane searchScrollPane = new JScrollPane();
		searchScrollPane.setLayout(null);
		searchScrollPane.setBounds(20, 100, 560,  200);
		searchScrollPane.setVisible(true);
		JTable searchTable = new JTable(new DefaultTableModel());
		((DefaultTableModel)searchTable.getModel()).setColumnCount(5);
		for(int i=0; i<headings.length; i++) {
			TableColumn col = searchTable.getTableHeader().getColumnModel().getColumn(i);
			col.setHeaderValue(headings[i]);
			col.setPreferredWidth(colWidth[i]);
		}
		searchTable.setBounds(1, 1, 556,  196);
		searchTable.setVisible(true);
		searchScrollPane.add(searchTable);
		searchPanel.add(searchScrollPane);

		// Search button ..
		JButton searchButton = new JButton("Search");
		searchButton.setBounds(490, 50, 90, 30);
		searchButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// When clicked, search database & populate a JTable ..
				String text = searchText.getText().trim();
				if (text.length() > 0) {
					performSearch(searchTable, searchText.getText());
				}
			}
		});
		searchPanel.add(searchButton);
		
		//// EDIT TAB ////

		JPanel editPanel = new JPanel();
		editPanel.setLayout(null);	// Set basic panel layout
	
		// Edit Title ..
		JLabel editTitle = new JLabel();
		editTitle.setBounds(20, 10, 300, 30);// x, y, width, height - (pixels)
		editTitle.setText("Edit");
		editTitle.setFont(new Font("Arial", Font.BOLD, 24));
		editTitle.setForeground(Color.red);
		editTitle.setVisible(true);
		editPanel.add(editTitle);

		//// TABBED PANE ////

		JTabbedPane tabs  = new JTabbedPane();
		tabs.setBounds(10, 10,  610,  340);

		tabs.addTab("Overview",  overviewPanel);
		tabs.addTab("Search",  searchPanel);
		tabs.addTab("Add/Edit",  editPanel);

		frame.add(tabs);
	}

	/**
	 * Populates the overview tab.
	 * 
	 * @param textbox JLabel - target of genre counts
	 */
	private void showOverview(JLabel textbox) {
		List<MediaRecord> list = db.getRecords("SELECT * FROM media");
		for (MediaRecord rec : list) {
			String[] genre = rec.getGenre().split("[,;\\|\\/]+");
			for (String g : genre) {
				counters.bump(g.trim().toUpperCase());
			}
		}
		StringBuilder sb = new StringBuilder();
		sb.append("<html><head><style>body {font-family:verdana;}</style></head><body>" +
				"<table><tr><td><i>Count</i></td><td><i>Genre</i></td></tr>");
		for (String name : counters.keySet()) {
			sb.append("<tr><td align=\"right\">" + counters.get(name) +
					"</td><td>" + name + "</td></tr>");
		}
		sb.append("</table></body></html>");
		textbox.setVerticalAlignment(JLabel.TOP);
		textbox.setText(sb.toString());		
	}

	/**
	 * Populates the search-results table based on user's input.
	 * 
	 * @param table JTable
	 * @param textString String - user's query string
	 */
	private void performSearch(JTable table, String textString) {
		DefaultTableModel model = (DefaultTableModel)(table.getModel());
		StringBuilder query = new StringBuilder();
		if (textString.equalsIgnoreCase("ALL")) {
			query.append("SELECT * FROM media");
		} else {
			for (String col : db.columns) {
				if (query.length() > 0)
					query.append(" OR ");
				query.append("`" + col + "` LIKE '%" + textString + "%'");
			}
			query.insert(0, "SELECT * FROM media WHERE ");
		}
		query.append(" ORDER BY title");
		List<MediaRecord> list = db.getRecords(query.toString());
		model.setRowCount(0);
		for (MediaRecord rec : list) {
			model.addRow(rec.getColumns());
		}
		table.setVisible(true);
	}

	/**
	 * Main.
	 * 
	 * @param args String[]
	 */
	public static void main(String[] args) {
		try {
			MediaMain media = new MediaMain();
			media.setupComponents();
			media.frame.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
