package com.eaglecrk.inventory;

import java.util.TreeMap;

/**
 * Counters.
 * 
 * @author Jesse, ECSS, 3-30-2017
 */
public class Counters extends TreeMap<String, Integer> {

	private static final long serialVersionUID = 1L; // req'd by this extends

	/**
	 * Creates a new Counters instance.
	 * 
	 */
	public Counters() {
		super();
	}

	/**
	 * Increments the given counter.
	 * 
	 * @param name String
	 */
	public void bump(String name) {
		Integer counter = get(name);
		if (counter == null) {
			counter = new Integer(1);
		} else {
			counter++;
		}
		put(name, counter);
	}

	/**
	 * Returns value of given counter.
	 * 
	 * @param name String
	 * @return int
	 */
	public int getCounter(String name) {
		Integer counter = get(name);
		return counter == null ? 0 : counter.intValue();
	}

	/**
	 * Returns all counters as a string.
	 * 
	 */
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (String name : keySet()) {
			sb.append(String.format("%,11d %s\n", get(name).intValue(), name));
		}
		return sb.toString();
	}
}
