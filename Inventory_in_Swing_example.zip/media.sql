DROP DATABASE IF EXISTS inventory;

CREATE DATABASE inventory;
USE inventory;

CREATE TABLE media (
	id			INT PRIMARY KEY AUTO_INCREMENT,
	scan_code	VARCHAR(32),
	title		VARCHAR(128),
	description	TEXT,
	media_type	ENUM('DVD','BLURAY'),
	genre		VARCHAR(32),
	minutes		INT,
	`year`		INT,
	location	VARCHAR(32),
	price		FLOAT,
	purchased	DATE,
	watched		DATE
) AUTO_INCREMENT=1001;

INSERT INTO media (title,description,media_type,genre,minutes,year)
	VALUES ('Star Wars','The story of Imperial Forces vs. the Galactic Empire.','DVD','SciFi',125,1977);
INSERT INTO media (title,description,media_type,genre,minutes,year)
	VALUES ('The Magic of Belle Isle','He takes a lakeside cabin for the summer in an effort to tap his original talent.','BluRay','Drama/Comedy',109,2012);
