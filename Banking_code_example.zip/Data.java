package com.eaglecrk.banking;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * Banking Data Access.
 * 
 * @author Jesse, ECSS, Mar2017
 *
 */
public class Data {

	private Connection conn;
	
	public Data() {
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/banking?useSSL=false", "addrbook", "addrbook");
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}
	
	public User getUser(String username, String password) {
		Map<String, User> records = getUsers("SELECT * FROM users WHERE username = '" + username + "'");
		return records.get(username);
	}
	
	public Map<String, User> getUsers() {
		return getUsers("SELECT * FROM users");
	}
	
	public Map<String, User> getUsers(String query) {
		Map<String, User> users = new TreeMap<>();
		try {
			Statement stmt = conn.createStatement();
	        ResultSet rs = stmt.executeQuery(query);
	        while (rs.next()) {
	        	int id = rs.getInt("id");
	        	String username = rs.getString("username");
	        	String lastName = rs.getString("lastname");
	        	String firstName = rs.getString("firstname");
	        	String email = rs.getString("email");
	        	String phone = rs.getString("phone");
	        	boolean admin = rs.getBoolean("admin");
	        	Date created = rs.getDate("created");
	        	User user = new User(id, username, null, lastName, firstName, email, phone, admin, created);
	        	users.put(username, user);
	        }
	        stmt.close();
	        return users;
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return null;
	}
	
	public boolean addUser(User user) {
		int i;
		try {
			PreparedStatement preparedStmt = conn.prepareStatement("INSERT INTO users VALUES(0,?,?,?,?,?,?,?,null)");
			preparedStmt.setString (1, user.getUsername());
			preparedStmt.setString (2, user.getPassword());
			preparedStmt.setString (3, user.getLastname());
			preparedStmt.setString (4, user.getFirstname());
			preparedStmt.setString (5, user.getEmail());
			preparedStmt.setString (6, user.getPhone());
			preparedStmt.setBoolean (7, user.isAdmin());
			i = preparedStmt.executeUpdate();		
		} catch (SQLException ex) {
			ex.printStackTrace();
			i = 0;
		}
		return i > 0;
	}
	
	public boolean removeUser(String username) {
		int i;
		try {
			PreparedStatement preparedStmt = conn.prepareStatement("DELETE FROM users WHERE username = ?");
			preparedStmt.setString (1, username);
			i = preparedStmt.executeUpdate();		
		} catch (SQLException ex) {
			ex.printStackTrace();
			i = 0;
		}
		return i > 0;
	}
	
	public Map<Integer, Account> getAccounts(int userId) {
		Map<Integer, Account> accounts = new TreeMap<>();
		try {
			PreparedStatement preparedStmt = conn.prepareStatement("SELECT id, `user`, `type`, lastdaily, lastbalance, created FROM accounts WHERE `user` = ?");
			preparedStmt.setInt (1, userId);
			ResultSet rs = preparedStmt.executeQuery();		
	        while (rs.next()) {
	        	int id = rs.getInt("id");
	        	int userid = rs.getInt("user");
	        	String type = rs.getString("type");
	        	Date lastDaily = rs.getDate("lastdaily");
	        	double lastBalance = rs.getDouble("lastbalance");
	        	Date created = rs.getDate("created");
	        	Account account = new Account(id, userid, type, lastDaily, lastBalance, created);
	        	accounts.put(id, account);
	        }
	        preparedStmt.close();
	        return accounts;
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return null;
	}
	
	public boolean accountExists(int accountNumber) {
		try {
			PreparedStatement preparedStmt = conn.prepareStatement("SELECT `user` FROM accounts WHERE id = ?");
			preparedStmt.setInt (1, accountNumber);
			ResultSet rs = preparedStmt.executeQuery();
			while (rs.next()) {
				preparedStmt.close();
				return true;
			}
			preparedStmt.close();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return false;
	}

	public boolean addAccount(String username, Account.AccountType accountType) {
		int i;
		try {
			PreparedStatement preparedStmt = conn.prepareStatement("INSERT INTO accounts VALUES(0,(SELECT id FROM users WHERE username=?),?,null,0.0,null)");
			preparedStmt.setString (1, username);
			preparedStmt.setString (2, accountType.name());
			i = preparedStmt.executeUpdate();		
		} catch (SQLException ex) {
			ex.printStackTrace();
			i = 0;
		}
		return i > 0;
	}
	
	public boolean removeAccount(int accountNumber) {
		int i;
		try {
			PreparedStatement preparedStmt = conn.prepareStatement("DELETE FROM accounts WHERE id = ?");
			preparedStmt.setInt (1, accountNumber);
			i = preparedStmt.executeUpdate();		
		} catch (SQLException ex) {
			ex.printStackTrace();
			i = 0;
		}
		return i > 0;
	}

	public boolean addTransaction(double amount, Transaction.TransactionType transType, int accountNumber, int otherAcctNumber) {
		int i;
		if (amount == Double.MIN_VALUE)
			return false;
		if (accountExists(accountNumber) && (transType == Transaction.TransactionType.DEPOSIT || transType == Transaction.TransactionType.WITHDRAWAL || accountExists(otherAcctNumber))) {
			try {
				PreparedStatement preparedStmt = conn.prepareStatement("INSERT INTO transactions VALUES(0,?,?,?,?,null)");
				preparedStmt.setDouble(1,  amount);
				preparedStmt.setString (2, transType.name());
				preparedStmt.setInt (3, accountNumber);
				preparedStmt.setInt (4, otherAcctNumber);
				i = preparedStmt.executeUpdate();		
			} catch (SQLException ex) {
				ex.printStackTrace();
				i = 0;
			}
			return i > 0;
		} else {
			return false;
		}
	}

	public double getAccountBalance(int accountNumber) {
		
		return 0.0;
	}
	
	public Map<Integer, Transaction> getTransactionHistory(Account account) {
		Map<Integer, Transaction> transactions = new TreeMap<>();
		try {
			PreparedStatement preparedStmt = conn.prepareStatement("SELECT t.id as 'id', amount, t.`type`, account, alt_account, datetime, CONCAT(u.firstname, ' ', u.lastname) as 'alt_name' FROM transactions t LEFT JOIN accounts a ON alt_account=a.id LEFT JOIN users u ON a.user=u.id WHERE account = ? AND datetime >= ?");
			preparedStmt.setInt (1, account.getAccountNumber());
			preparedStmt.setDate (2, account.getLastUpdate());
			ResultSet rs = preparedStmt.executeQuery();		
	        while (rs.next()) {
	        	int id = rs.getInt("id");
	        	double amount = rs.getDouble("amount");
	        	String type = rs.getString("type");
	        	int acctNum = rs.getInt("account");
	        	int altAcctNum = rs.getInt("alt_account");
	        	Date datetime = rs.getDate("datetime");
	        	String altName = rs.getString("alt_name");
	        	Transaction transaction = new Transaction(id, amount, type, acctNum, altAcctNum, datetime, altName);
	        	transactions.put(id, transaction);
	        }
	        preparedStmt.close();
	        return transactions;
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return null;
	}
}
