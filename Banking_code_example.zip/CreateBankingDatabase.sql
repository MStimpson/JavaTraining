-- Banking System Database Schema (MySQL)
-- Jesse, ECSS, Mar2017

DROP DATABASE IF EXISTS banking;

CREATE DATABASE banking;
USE banking;

CREATE TABLE users (
	id			INT PRIMARY KEY AUTO_INCREMENT,			-- User's ID
	username	VARCHAR(32) UNIQUE NOT NULL,			-- Username
	passwd		VARCHAR(32) DEFAULT 'password',			-- Password
	lastname	VARCHAR(32) NOT NULL,					-- User's last nane
	firstname	VARCHAR(32),							-- User's first name
	email		VARCHAR(64),							-- User's email address
	phone		VARCHAR(16),							-- User's phone number
	admin		BOOLEAN	DEFAULT 0,						-- Privileged user (adminstrator), if true (non-zero)
	created		TIMESTAMP DEFAULT CURRENT_TIMESTAMP() --
) AUTO_INCREMENT=1001;									-- User IDs begin at 1,001

CREATE TABLE accounts (
	id			INT PRIMARY KEY AUTO_INCREMENT,			-- User's account number
	`user`		INT NOT NULL,							-- User's ID
	`type`		ENUM('UNDEFINED', 'CHECKING', 'SAVINGS', 'IRA') NOT NULL,
	lastdaily	TIMESTAMP DEFAULT CURRENT_TIMESTAMP(), -- Last daily run
	lastbalance	DECIMAL(16,6) NOT NULL DEFAULT 0.0,		-- Balance at last daily run
	created		TIMESTAMP DEFAULT CURRENT_TIMESTAMP() --
) AUTO_INCREMENT=1000001;								-- Account numbers begin at 1,000,001

CREATE TABLE transactions (
	id			INT PRIMARY KEY AUTO_INCREMENT,			-- Transaction ID
	amount		DECIMAL(16,6) NOT NULL,					-- Dollar amount
	`type`		ENUM('UNDEFINED', 'DEPOSIT', 'WITHDRAWAL', 'TRANSFEROUT', 'TRANSFERIN'),
	account		INT NOT NULL,							-- User's account number
	alt_account	INT DEFAULT 0,							-- Other user's account number (or 0)
	datetime	TIMESTAMP DEFAULT CURRENT_TIMESTAMP()	-- Transaction Date/Time
);														-- Transaction IDs begin at 1

-- Create initial system administrator ..
INSERT INTO users VALUES (1, 'admin', 'admin', 'Administrator', 'System', 'admin@banking.xyz', '987-654-3210', 1, null);
