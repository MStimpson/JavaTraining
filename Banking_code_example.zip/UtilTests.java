package com.eaglecrk.banking;

import static org.junit.Assert.*;

import org.junit.Test;

public class UtilTests {

	@Test
	public void TestBefore() {
		assertEquals("key", Util.getBefore("=",  "key = value"));
	}
	
	@Test
	public void TestAfter() {
		assertEquals("value", Util.getAfter("=",  "key = value"));
	}
	
	@Test
	public void testClean() {
		assertEquals("abc", Util.clean("  abc "));
		assertEquals("", Util.clean("  "));
		assertEquals("", Util.clean(null));
	}

	@Test
	public void testIsEmpty() {
		assertTrue(Util.isEmpty(null));
		assertTrue(Util.isEmpty(" "));
		assertTrue(Util.isEmpty(" \t\n"));
		assertFalse(Util.isEmpty(" ."));
	}

	@Test
	public void testIsNotEmpty() {
		assertFalse(Util.isNotEmpty(null));
		assertFalse(Util.isNotEmpty(" "));
		assertFalse(Util.isNotEmpty(" \t\n"));
		assertTrue(Util.isNotEmpty(" ."));
	}

	@Test
	public void testIsInteger() {
		assertTrue(Util.isInteger("0123"));
		assertFalse(Util.isInteger("012.3"));
		assertFalse(Util.isInteger("O123"));
	}

	@Test
	public void testIsDecimal() {
		assertTrue(Util.isDecimal("0123"));
		assertTrue(Util.isDecimal("012.3"));
		assertTrue(Util.isDollar("412.30"));
		assertFalse(Util.isDollar("412.30.1"));
		assertFalse(Util.isDecimal("O123"));
	}

	@Test
	public void testIsDollar() {
		assertTrue(Util.isDollar("12.3"));
		assertTrue(Util.isDollar("120"));
		assertTrue(Util.isDollar("$12.3"));
		assertTrue(Util.isDollar("$12"));
		assertTrue(Util.isDollar("412.30"));
		assertFalse(Util.isDollar("412.3.3"));
		assertFalse(Util.isDollar("O12.3"));
	}

	@Test
	public void testIsDigits() {
		assertTrue(Util.isDigits("41230"));
		assertFalse(Util.isDigits("-41230"));
	}

	@Test
	public void testToInt() {
		assertEquals(3, Util.toInt(" 3 "));
	}

	@Test
	public void testToDouble() {
		assertEquals(3.1, Util.toDouble("3.1"), 0.000001);
	}

	@Test
	public void testDisplay() {
		assertEquals("&lt;Tag&gt;&amp;<br/>", Util.display("<Tag>&\n"));
	}

	@Test
	public void testToTableRow() {
		String[] styles = { "style1" };
		assertEquals("<tr><td class=\"style1\">value1</td><td>value2</td></tr>\n",
				Util.toTableRow("value1;value2", ";", 2, styles));
	}

	@Test
	public void testGetVal() {
		String[] array = { "A", "B" };
		assertEquals("A", Util.getVal(array,  0));
		assertEquals("B", Util.getVal(array,  1));
		assertEquals("", Util.getVal(array,  2));
		assertEquals("", Util.getVal(array,  3));
	}

}
