package com.eaglecrk.banking;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * Banking System.
 * 
 * @author Jesse, ECSS, Mar2017
 *
 */
public class Banking {

	private static Scanner console;
	private Data data;
	private User user = new User();

	public Banking() {
		data = new Data();
	}

	public void help() {
		cons("Commands:");
		cons("  help");
		cons("  quit");
		if (user.isLoggedIn()) {
			cons("  logout");
			if (user.isAdmin()) {
				cons("  list users");
				cons("  create user <username> <firstname> <lastname>");
				cons("  remove user <username>");
				cons("  create account <username> <type, one of: " + joinOr(Account.getAvailableTypes()) + ">");
				cons("  remove account <accountNumber>");
			}
			if (user.hasAccounts()) {
				cons("  deposit <amount> into <accountNumber>");
				cons("  withdraw <amount> from <accountNumber>");
				cons("  transfer <amount> from <accountNumber> to <otherAccountNumber>");
				cons("  overview");
				cons("  view account <accountNumber>");
			} else {
				cons("  (no accounts are available for " + user.getFirstname() + " " + user.getLastname() + ")");
			}
		} else {
			cons("  login <username>");
		}
	}

	public static String getVal(String[] array, int index) {
		return index < array.length ? array[index].trim() : "";
	}
	
	public void bankingSystem() {
		cons("Simple Banking Services ..\n Enter help at anytime.\n Please login ...");
		boolean active = true;
		while (active) {
			String[] cmd = userInput("Banking").split(" ");
			switch (getVal(cmd, 0).toUpperCase()) {
				case "QUIT":
					active = false;
					if (user.isLoggedIn()) {
						cons("Logging out " + user.getUsername());
					}
					cons("Bye.\n");
					break;
				case "HELP":
					help();
					break;
				case "LOGOUT":
					cons(user.getUsername() + " is logged out.\nYou may log back in, or quit if finished.");
					user = new User();
					break;
				case "LOGIN":
					if (user.isLoggedIn()) {
						cons("Logging out " + user.getUsername());
						user = new User();
					}
					user = data.getUser(getVal(cmd, 1), getVal(cmd, 2));
					if (user != null && user.isLoggedIn()) {
						user.setAccounts(data.getAccounts(user.getId()));
						cons("Welcome " + user.getFirstname() + " " + user.getLastname());
					} else {
						cons("Sorry, unable to log in as '" + getVal(cmd, 1) + "'");
						user = new User();
					}
					// include overview with login ..
				case "OVERVIEW":
					if (user.isLoggedIn())
						cons("Overview:\n" + user.toString());
					break;
				case "DEPOSIT":
					if (user.isLoggedIn()) {
						if (getVal(cmd, 2).equalsIgnoreCase("INTO") && Util.isDollar(getVal(cmd, 1)) && Util.isDigits(getVal(cmd, 3))) {
							if (user.hasAccount(Util.toInt(getVal(cmd, 3)))) {
								cons("Deposit " + (data.addTransaction(Util.toDouble(getVal(cmd, 1)), Transaction.TransactionType.DEPOSIT, Util.toInt(getVal(cmd, 3)), 0)? "succeeded" : "failed"));
							} else {
								cons("Account number does not exist");
							}
						} else {
							cons("Syntax error");
						}
					}
					break;
				case "WITHDRAW":
					if (user.isLoggedIn()) {
						if (getVal(cmd, 2).equalsIgnoreCase("FROM") && Util.isDollar(getVal(cmd, 1)) && Util.isDigits(getVal(cmd, 3))) {
							if (user.hasAccount(Util.toInt(getVal(cmd, 3)))) {
								cons("Withdraw " + (data.addTransaction(0.0 - Util.toDouble(getVal(cmd, 1)), Transaction.TransactionType.WITHDRAWAL, Util.toInt(getVal(cmd, 3)), 0)? "succeeded" : "failed"));
							} else {
								cons("Account number does not exist");
							}
						} else {
							cons("Syntax error");
						}
					}
					break;
				case "TRANSFER":
					if (user.isLoggedIn()) {
						boolean fmSuccess = false, toSuccess = false;
						if (getVal(cmd, 2).equalsIgnoreCase("FROM") && getVal(cmd, 4).equalsIgnoreCase("TO") && Util.isDollar(getVal(cmd, 1)) && Util.isDigits(getVal(cmd, 3)) && Util.isDigits(getVal(cmd, 5))) {
							if (user.hasAccount(Util.toInt(getVal(cmd, 3)))) {
								fmSuccess = data.addTransaction(0.0 - Util.toDouble(getVal(cmd, 1)), Transaction.TransactionType.TRANSFEROUT, Util.toInt(getVal(cmd, 3)), Util.toInt(getVal(cmd, 5)));
								toSuccess = data.addTransaction(Util.toDouble(getVal(cmd, 1)), Transaction.TransactionType.TRANSFERIN, Util.toInt(getVal(cmd, 5)), Util.toInt(getVal(cmd, 3)));
								cons("Transfer " + (fmSuccess && toSuccess ? "succeeded" : "failed"));
							} else {
								cons("Account number does not exist");
							}
						} else {
							cons("Syntax error");
						}
					}
					break;
				case "VIEW":
					if (user.isLoggedIn()) {
						if (getVal(cmd, 1).equalsIgnoreCase("ACCOUNT")) {
							Account acct = user.getAccount(getVal(cmd, 2));
							if (acct != null) {
								Map<Integer, Transaction> trans = data.getTransactionHistory(acct);
								double total = 0.0;
								for (Transaction t : trans.values()) {
									total += t.getAmount();
									cons(" " + t.toString(user));
								}
								cons(String.format(" Current balance: %,15.2f",  total));
							} else {
								cons("Account number does not exist");
							}
						} else {
							cons("Syntax error");
						}
					}
					break;
				case "LIST":
					if (user.isAdmin()) {
						if (getVal(cmd, 1).equalsIgnoreCase("users")) {
							Map<String, User> users = data.getUsers();
							for (User user : users.values()) {
								cons(String.format("%-12s %-16s %-16s%s",
										user.getUsername(), user.getFirstname(), user.getLastname(),
										(user.isAdmin() ? " (Admin)" : "")));
							}
						} else {
							cons("Unknown category " + getVal(cmd, 1));
						}
					} else {
						cons("Unknown command: LIST");
					}
					break;
				case "CREATE":
					if (user.isAdmin()) {
						if (getVal(cmd, 1).equalsIgnoreCase("user")) {
							cons("Add user " + getVal(cmd, 2) + ": " +
								(data.addUser(new User(getVal(cmd, 2), getVal(cmd, 4), getVal(cmd, 3), false)) ? "succeeded" : "failed"));
						} else if (getVal(cmd, 1).equalsIgnoreCase("account")) {
							Account.AccountType accountType;
							try {
								accountType = Account.AccountType.valueOf(getVal(cmd, 3).toUpperCase());
							} catch (IllegalArgumentException iae) {
								accountType = null;
							}
							if (accountType != null)
								cons("Add account " + (data.addAccount(getVal(cmd, 2), accountType) ? "succeeded" : "failed"));
							else
								cons("Unknown account type: " + getVal(cmd, 3));
						}
					} else {
						cons("Unknown command: CREATE");
					}
					break;
				case "REMOVE":
					if (user.isAdmin()) {
						if (getVal(cmd, 1).equalsIgnoreCase("user")) {
							cons("Remove user " + (data.removeUser(getVal(cmd, 2)) ? "succeeded" : "failed"));
						} else if (getVal(cmd, 1).equalsIgnoreCase("account")) {
							if (Util.isDigits(getVal(cmd, 2))) {
								cons("Remove account " + (data.removeAccount(Util.toInt(getVal(cmd, 2))) ? "succeeded" : "failed"));
							} else {
								cons("Invalid account number.");
							}
						}
					} else {
						cons("Unknown command: REMOVE");
					}
					break;					
				default:
						cons("Unknown command: " + getVal(cmd, 0).toUpperCase());
			}
		}
	}

	/**
	 * Joins strings, comma delimited with 'or' before the last.
	 * 
	 * @param list List<String>
	 * @return String
	 */
	public String joinOr(List<String> list) {
		if (list == null)
			return "-no items found-";
		else if (list.size() == 1)
			return list.get(0);
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < list.size(); i++) {
			sb.append(i > 0 ? i == list.size() - 1 ? " or " : ", " : "");
			sb.append(list.get(i));
		}
		return sb.toString();
	}

	/**
	 * Displays console output.
	 * 
	 * @param message String
	 */
	public static void cons(String message) {
		System.out.println(message);
	}

	/**
	 * Prompts for console input.
	 * 
	 * @param prompt String
	 * @return String
	 */
	public static String userInput(String prompt) {
	    System.out.print(prompt + " >");
	    String input = console.nextLine();
	    return input;
	}

	/**
	 * Main.
	 * 
	 * @param args String[]
	 */
	public static void main(String[] args) {
		console = new Scanner(System.in);

		Banking bank = new Banking();
		bank.bankingSystem();
	}

}
