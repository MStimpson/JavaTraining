package com.eaglecrk.banking;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.eaglecrk.banking.Account.AccountType;

/**
 * Banking Transaction Record.
 * 
 * @author Jesse, ECSS, Mar2017
 *
 */
public class Transaction {

	public static enum TransactionType {
		UNDEFINED, DEPOSIT, WITHDRAWAL, TRANSFEROUT, TRANSFERIN
	};

	private int id;
	private double amount;
	private TransactionType transactionType;
	private int accountNumber;
	private int otherAccountNumber;
	private Date datetime;
	private String altName;

	public Transaction(int id, double amount, String transactionType, int accountNumber, int otherAccountNumber, Date datetime, String altName) {
		this.id = id;
		this.amount = amount;
		this.transactionType = toTransactionType(transactionType);
		this.accountNumber = accountNumber;
		this.otherAccountNumber = otherAccountNumber;
		this.datetime = datetime;
		this.altName = altName;
	}
	
	public static TransactionType toTransactionType(String transType) {
		try {
			TransactionType type = TransactionType.valueOf(transType.trim().toUpperCase());
			return type;
		} catch (Exception ex) {
			return TransactionType.UNDEFINED;
		}
	}

	public static List<String> getAvailableTypes() {
		boolean first = true;
		List<String> list = new ArrayList<>();
		for (TransactionType t : TransactionType.values()) {
			if (first)
				first = false;	// (ignore 'Undefined')
			else
				list.add(t.name());
		}
		return list;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the amount
	 */
	public double getAmount() {
		return amount;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setAmount(double amount) {
		this.amount = amount;
	}

	/**
	 * @return the transactionType
	 */
	public TransactionType getTransactionType() {
		return transactionType;
	}

	/**
	 * @param transactionType the transactionType to set
	 */
	public void setTransactionType(TransactionType transactionType) {
		this.transactionType = transactionType;
	}

	/**
	 * @return the accountNumber
	 */
	public int getAccountNumber() {
		return accountNumber;
	}

	/**
	 * @param accountNumber the accountNumber to set
	 */
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * @return the otherAccountNumber
	 */
	public int getOtherAccountNumber() {
		return otherAccountNumber;
	}

	/**
	 * @param otherAccountNumber the otherAccountNumber to set
	 */
	public void setOtherAccountNumber(int otherAccountNumber) {
		this.otherAccountNumber = otherAccountNumber;
	}

	/**
	 * @return the datetime
	 */
	public Date getDatetime() {
		return datetime;
	}

	/**
	 * @param datetime the datetime to set
	 */
	public void setDatetime(Date datetime) {
		this.datetime = datetime;
	}
	
	public String getDateString() {
		return new SimpleDateFormat("M-d-yyyy").format(datetime);
	}

	private String altName(int acctId, User user) {
		Account acct = user.getAccount("" + otherAccountNumber);
		String alt = acct != null ? acct.getAccountType().name() : altName;
		return alt != null && alt.length() > 0 ?
				String.format(" (%s %s)", (transactionType == TransactionType.TRANSFERIN ? "from" : "to"), alt) : "";
	}
	
//	public String toString(User user) {
//		return String.format("%d %s %,9.2f%s",
//				accountNumber, transactionType.name(), amount, altName(accountNumber, user));
//	}
	
	public String toString(User user) {
		return String.format("%09d %-12s %10s %,9.2f%s",
				accountNumber, transactionType.name(), getDateString(), amount, altName(accountNumber, user));
	}

}
