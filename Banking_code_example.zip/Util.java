package com.eaglecrk.banking;

public class Util {

	public static String getBefore(String delimiter, String text) {
		if (text != null) {
			int indx = text.indexOf(delimiter);
			return indx < 0 ? text : text.substring(0, indx).trim();
		}
		return "";
	}

	public static String getAfter(String delimiter, String text) {
		if (text != null) {
			int indx = text.indexOf(delimiter);
			return indx < 0 ? "" : text.substring(indx + delimiter.length() + 1);
		}
		return "";
	}

	public static String clean(String text) {
		return text == null ? "" : text.trim();
	}
	
	public static boolean isEmpty(String text) {
		return text == null || text.trim().length() == 0;
	}

	public static boolean isNotEmpty(String text) {
		return ! isEmpty(text);
	}
	
	public static boolean isInteger(String text) {
		return text.matches("^[0-9]+$");
	}
	
	public static boolean isDecimal(String text) {
		return text.matches("^[0-9]+\\.?[0-9]*$");
	}

	public static boolean isDollar(String text) {
		return text.matches("^[ \\t]*[\\$]?[0-9]+\\.?[0-9]*[ \\t]*$");
	}

	public static boolean isDigits(String text) {
		return text.matches("^[ \\t]*[0-9]+[ \\t]*$");
	}

//	public static int toInt(String num) {
//		try {
//			return Integer.parseInt(num);
//		} catch (Exception ex) {
//			return 0;
//		}
//	}
	
	public static int toInt(String value) {
		try {
			return Integer.parseInt(value.trim());
		} catch (Exception ex) {
			//cons("Invalid amount entered");
			return Integer.MIN_VALUE;
		}
	}
	
	public static double toDouble(String value) {
		try {
			return Double.parseDouble(value.trim());
		} catch (Exception ex) {
			//cons("Invalid amount entered");
			return Double.MIN_VALUE;
		}
	}

	public static String display(String text) {
		return text
				.replaceAll("&", "&amp;")
				.replaceAll("<", "&lt;")
				.replaceAll(">", "&gt;")
				.replaceAll("\\n", "<br/>");
    }

	public static String toTableRow(String text, String delimiter, int maxColumns, String[] styles) {
		int s = 0;
		StringBuilder sb = new StringBuilder();
		String[] tokens = text.split(delimiter,  maxColumns);
		sb.append("<tr>");
		for (String tok : tokens) {
			String style = (styles != null && styles.length > s ? (" class=\"" + styles[s] + "\"") : "");
			sb.append("<td" + style + ">" + tok + "</td>");
			s++;
		}
		sb.append("</tr>\n");
		return sb.toString();
	}
	
	public static String getVal(String[] array, int index) {
		return index < array.length ? array[index].trim() : "";
	}

}
