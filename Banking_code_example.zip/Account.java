package com.eaglecrk.banking;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

/**
 * Banking Account Record
 * 
 * @author Jesse, ECSS, Mar2017
 *
 */
public class Account {
	
	public static enum AccountType {
		UNDEFINED, CHECKING, SAVINGS, IRA };

	private int accountNumber;
	private int userId;
	private AccountType accountType;
	private Date lastUpdate;
	private double lastBalance;
	private Date created;

	public Account(int accountNumber, int userId, String accountType, Date lastUpdate, double lastBalance, Date created) {
		this.accountNumber = accountNumber;
		this.userId = userId;
		this.accountType = toAccountType(accountType);
		this.lastUpdate = lastUpdate;
		this.lastBalance = lastBalance;
		this.created = created;
	}

	public static AccountType toAccountType(String acctType) {
		try {
			AccountType type = AccountType.valueOf(acctType.trim().toUpperCase());
			return type;
		} catch (Exception ex) {
			return AccountType.UNDEFINED;
		}
	}
	
	public static List<String> getAvailableTypes() {
		boolean first = true;
		List<String> list = new ArrayList<>();
		for (AccountType t : AccountType.values()) {
			if (first)
				first = false;	// (ignore 'Undefined')
			else
				list.add(t.name());
		}
		return list;
	}

	public String getAccountInfo() {
		return (""+accountNumber).substring(-4) + " " + accountType.name();
	}
	
	// GETTERS & SETTERS

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public AccountType getAccountType() {
		return accountType;
	}

	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}

	/**
	 * @return the lastUpdate
	 */
	public Date getLastUpdate() {
		return lastUpdate;
	}

	/**
	 * @param lastUpdate the lastUpdate to set
	 */
	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	/**
	 * @return the lastBalance
	 */
	public double getLastBalance() {
		return lastBalance;
	}

	/**
	 * @param lastBalance the lastBalance to set
	 */
	public void setLastBalance(double lastBalance) {
		this.lastBalance = lastBalance;
	}

	/**
	 * @return the created
	 */
	public Date getCreated() {
		return created;
	}

	/**
	 * @param created the created to set
	 */
	public void setCreated(Date created) {
		this.created = created;
	}

	public String toString() {
		return String.format("%09d %-10s",  accountNumber, accountType.name());
	}
}
