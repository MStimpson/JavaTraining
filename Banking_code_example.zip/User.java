package com.eaglecrk.banking;

import java.sql.Date;
import java.util.Map;
import java.util.Set;

/**
 * Banking User Record.
 * 
 * @author Jesse, ECSS, Mar2017
 *
 */
public class User {

	private int id = 0;
	private String username = null;
	private String password = "password";
	private String lastname = null;
	private String firstname = null;
	private String email = null;
	private String phone = null;
	private boolean admin = false;
	private Date created = null;
	
	private Map<Integer, Account> accounts;

	/**
	 * Creates empty user record.
	 * 
	 */
	public User() {
	}

	/**
	 * Creates new user record.
	 * 
	 * @param username
	 * @param lastname
	 * @param firstname
	 * @param admin
	 */
	public User(String username, String lastname, String firstname, boolean admin) {
		this(0, username, null, lastname, firstname, null, null, admin, null);
	}

	/**
	 * Creates new user record.
	 *
	 * @param id
	 * @param username
	 * @param password
	 * @param lastname
	 * @param firstname
	 * @param email
	 * @param phone
	 * @param admin
	 */
	public User(int id, String username, String password, String lastname, String firstname, String email, String phone, boolean admin, Date created) {
		this.id = id;
		this.username = username;
		this.password = password;
		this.lastname = lastname;
		this.firstname = firstname;
		this.email = email;
		this.phone = phone;
		this.admin = admin;
		this.created = created;
	}

	public boolean isLoggedIn() {
		return id > 0 && Util.isNotEmpty(username);
	}
	
	public boolean hasAccounts() {
		return accounts != null && accounts.size() > 0;
	}
	
	public boolean hasAccount(int accountNumber) {
		return hasAccounts() && accounts.containsKey(accountNumber);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public boolean isAdmin() {
		return admin;
	}

	public void setAdmin(boolean admin) {
		this.admin = admin;
	}

	public Map<Integer, Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(Map<Integer, Account> accounts) {
		this.accounts = accounts;
	}
	
	public Account getAccount(String id) {
		return accounts.get(new Integer(id));
	}
	
	public String getWelcome() {
		return isLoggedIn() ? ("Welcome " + firstname + " " + lastname) : "Please sign in";
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("  %sLogged in as username %s, Id: %d, Name: %s %s\n\n  Accounts:\n",
				(isLoggedIn() ? "" : "Not "), username, id, firstname, lastname));
		if (hasAccounts()) {
			for (Account acct : accounts.values()) {
				sb.append("    " + acct.toString() + "\n");
			}
		} else {
			sb.append("    (no accounts available)\n");
		}
		return sb.toString();
	}
}
